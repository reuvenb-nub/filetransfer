
var contract = artifacts.require("Crowdsale"); 
module.exports = function(deployer) {
   deployer.deploy(contract);
};

